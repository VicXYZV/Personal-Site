fun main() {
  print("Digite o seu nome: ") 
  val nome = readLine() 
  print("Qual é a sua idade: ")
  val idade = readLine()?.toIntOrNull() ?: 0
  println("Olá $nome! Você tem $idade anos.")
}
