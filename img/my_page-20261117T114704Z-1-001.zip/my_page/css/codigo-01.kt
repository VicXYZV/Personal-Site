fun main(){
    print("Digite o seu nome: ")
    val nome = readLine() // lê a entrada do usuário como String
    // print é diferente do println
    println("Olá, $nome! Bem-vindo ao Kotlin <3")
    // Como teste
    print("1º forma!")
    println("2º forma!")
}
